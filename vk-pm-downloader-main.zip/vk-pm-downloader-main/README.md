# VK PM Downloader

Исходный код сайта [zpix1.github.io/vk-pm-downloader](https://zpix1.github.io/vk-pm-downloader/) долгое время был закрыт. Сейчас сайт доступен для использования всем, без ограничений и бесплатно.
